hierarchy of modules:

- tb.v
    - ahb_accelerator.sv
        - ahb_interpreter.sv
            - ahb_defs.v
        - accelerator_wrapper.v
            - accelerator.v
